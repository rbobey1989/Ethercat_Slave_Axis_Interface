*PADS-LIBRARY-PART-TYPES-V9*

XAL5050-822MEC XAL5050822MEC I IND 7 1 0 0 0
TIMESTAMP 2026.05.10.14.05.19
"Mouser Part Number" 994-XAL5050-822MEC
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Coilcraft/XAL5050-822MEC?qs=zCSbvcPd3pZDEPpKfFCYbg%3D%3D
"Manufacturer_Name" COILCRAFT
"Manufacturer_Part_Number" XAL5050-822MEC
"Description" Power Inductors - SMD 8.2uH Shld 20% 6.1A 34.95mOhms AECQ2
"Datasheet Link" https://www.coilcraft.com/pdfs/xal50xx.pdf
"Geometry.Height" 5.1mm
GATE 1 2 0
XAL5050-822MEC
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
550703/2055088/2.50/2/4/Inductor
