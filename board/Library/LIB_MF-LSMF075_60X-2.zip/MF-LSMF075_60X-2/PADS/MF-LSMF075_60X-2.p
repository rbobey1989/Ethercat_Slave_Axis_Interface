*PADS-LIBRARY-PART-TYPES-V9*

MF-LSMF075_60X-2 MFLSMF07560X2 I ANA 7 1 0 0 0
TIMESTAMP 2026.05.10.20.08.14
"Mouser Part Number" 652-MF-LSMF075/60X-2
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Bourns/MF-LSMF075-60X-2?qs=Z%252BL2brAPG1I8QYFgSxUFUQ%3D%3D
"Manufacturer_Name" Bourns
"Manufacturer_Part_Number" MF-LSMF075/60X-2
"Description" 2920 Resettable SMD PPTC 0.75A/60V
"Datasheet Link" http://www.bourns.com/docs/Product-Datasheets/MF-LSMF.pdf
"Geometry.Height" 1.7mm
GATE 1 2 0
MF-LSMF075_60X-2
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
18875137/2055088/2.50/2/2/Resettable Fuse
